#include "node.h"


using namespace std;


// constructor for internal node
InternalNode :: InternalNode()
{
	isLeaf = false;
}


// function for insertion in an internal node
void InternalNode :: Insert(int key, Node* rightChild)
{
	//do we find the key we want?
	vector<int>::iterator index = lower_bound(keys.begin(), keys.end(), key);
	//takes the position in the vector and insert the key
	keys.insert(index, key);

	// insert right child in the immediately next index in the children vector
	index = lower_bound(keys.begin(), keys.end(), key);
	children.insert(children.begin() + (index - keys.begin() + 1), rightChild);
}


// function for insertion in a new internal root node
void InternalNode :: Insert(int key, Node* leftChild, Node* rightChild)
{
	// insert key, left child and right child
	keys.push_back(key);
	//push the leftchild into the end of the vector, when we search, we know use the index of the key we found as for the node
	children.push_back(leftChild);
	//the first elements we push is left, and the second element we push is the right child.
	children.push_back(rightChild);
	Left=leftChild;
	Right=rightChild;

}


// function for splitting an internal node
Node* InternalNode :: Split(int* keyToParent)
{
	int length = keys.size();

	// create a new right internal node
	InternalNode* rightNode = new InternalNode;

	// key to be moved up to the parent is the middle element in the current internal node
	*keyToParent = keys[length/2];

	//assign the content of the nodes staring from the middle to the right most into the rightnode and then 
	//do the same for the child
	rightNode->keys.assign(keys.begin() + (length/2 + 1), keys.end());
	rightNode->children.assign(children.begin() + (length/2 + 1), children.end());
	//How do we make the left children, well, we simply erase the contend of nodes starting from the middle to the rightmost
	keys.erase(keys.begin() + length/2, keys.end());
	//same goes for the children
	children.erase(children.begin() + (length/2 + 1), children.end());

	// return the new right internal node
	return rightNode;
}


// getter function for accessing children
vector<Node*> InternalNode :: Get_Children()
{
	// return the current child vector
	return children;
}

Node* InternalNode :: Get_Left()
{
	//return the left
	return Left;
}

Node* InternalNode :: Get_Right()
{
	//return the right
	return Right;
}

