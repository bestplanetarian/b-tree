#include<iostream>
#include<string>
#include<fstream>
#include<cstdlib>
#include<cstring>

using namespace std;
#include "node.h"



int main(int argc, char** argv)
{
     int pos=0;
     int key1=0;
     int key=0;
     int key2=0;
     class BPlusTree tree;

     int m=0;
     string line;
     if(!argv[1]){
         cout<<"please create a txt file named input.txt in the src directory"<<endl;
     }
     ifstream input(argv[1]);
    if(input.is_open())
     {
       getline(input,line);
       //time to split the first line in order to receive correct m number;
       //first we need to check if the first word in the first line is 
       if(0==line.compare(0,10,"Initialize")){
            //  char cstr[line.size()+1];
            //  strcpy(cstr, line.c_str());
            //  //cout<<cstr<<'\n';
            //  point1=strtok(cstr, ")");
            //  //cout<<point1<<endl;  
            //  point2=strtok(point1, "(");
             m=atoi(line.substr(11,line.size()-12).c_str());
             //eh, takes me long time to figure it out
             //ok then let's start initialize
             //cout<<m<<endl;
             //initialize the b+ tree
             tree.Initialize(m);
             // open the output file for writing results
	        tree.Open_Output_File();
            }   
       else{
           cout<<"wrong way";
        }
        while(getline(input,line)){
           pos=-1;
           key=0;
           key1=0;
           key2=0;
           string value;
           if(0==line.compare(0,6,"Insert"))
           {
                pos=line.find(",");
                key=atoi(line.substr(7,pos-7).c_str());
                //not sure how many decimals are for value
                value=line.substr(pos+1,line.size()-2-pos);
                //doing the insert here please
                //cout<<key<<","<<value<<'\n';
                tree.Insert(key, value);
           }
           else if(0==line.compare(0,6,"Delete"))
           {
                key=atoi(line.substr(7,line.size()-8).c_str());
                //doing delete here please;
                tree.Delete(key);    
               
           }
           else if(0==line.compare(0,6,"Search"))
           {
                pos=line.find(",");
                if(pos==-1)
                {
                   key=atoi(line.substr(7,line.size()-8).c_str());
                   //doing search here please
                   tree.Search(key);
                }else{
                     key1=atoi(line.substr(7,pos-7).c_str());
                     key2=atoi(line.substr(pos+1,line.size()-2-pos).c_str());\
                     //doing search here please;
                     tree.Search(key1, key2);
                }
           }
           // close the output file
	     


        } 
           
       }
           tree.Close_Output_File();
           cout<<endl<<OUTPUT_FILE<<endl;    
    
    //  if(input.is_open())
    //  {
    //      while(getline(input, line))
    //      {
    //          cout<<line<<'\n';
    //      }
    //  }

    //time to split the first line in order to receive correct m number;
     
     return 0;
    
}
