#include "node.h"
#include<math.h>


using namespace std;


// function for searching from root to leaf node and pushing on to a stack, here we use the property of the stack
void BPlusTree :: Search_Path(Node* node, int key, stack<Node*>* path)
{
	// push node to stack
        path->push(node);

	// check if the node pushed to stack is an internal node
	if(!node->Get_IsLeaf())
        {
		// search for the given key in the current node
		vector<int> keys = node->Get_Keys();
		// vector for all children it has
		vector<Node*> children = node->Get_Children();
		//find the children where the key value appear
    vector<int>::iterator index = lower_bound(keys.begin(), keys.end(), key);

		// check if key is found
		if(key == keys[index - keys.begin()])
		{
	     //According to the property of the b + tree, the first key of the right child node is always same as the parent key   
                	Search_Path(children[(index - keys.begin()) + 1], key, path);
		}

		// if key is not found
		else
		{
			// recursively repeat by searching the path through the corresponding left child index
			Search_Path(children[index - keys.begin()], key, path);
		}
        }
}


// function to destroy the tree
void BPlusTree :: Destroy(Node* node)
{
	// recursively repeat the function to delete all the nodes level by level, starting with the leaf nodes
	if (!node->Get_IsLeaf())
	{
  	        vector<Node*> children = node->Get_Children();
                for(vector<Node*>::iterator index = children.begin(); index != children.end(); index++)
                {
                        Destroy(*index);
        	}
	}
	delete(node);
}





// operation: Initialize(m)
void BPlusTree :: Initialize(int m)
{
	order = m;
	root = NULL;
}


// operation: Insert(key, value)
void BPlusTree :: Insert(int key, string value)
{
	// check if tree is empty
	if(NULL == root)
	{
		//first element supposed to be leaf
		root = new LeafNode;
		root->Insert(key, value);
	}

	// if it is a subsequent insertion
	else
	{
		Node* leftNode = NULL;
		Node* rightNode = NULL;
		//for spliting the node into left node and right node
		int* keyToParent = new int;
		//setting the root not be popped
		bool rootPopped = false;
		
		// obtain the search path from the root to leaf node and push it on to a stack, 
		// using stack here because of its last in first out property
		stack<Node*>* path = new stack<Node*>;
		Search_Path(root, key, path);

		//we find the corresponding value
		path->top()->Insert(key, value);

		// Split the current node and insert the middle key & children in to the parent. Perform
		// this as long as there is an imbalance in the tree, moving up the stack every iteration.
		while(path->top()->Get_Keys().size() == order)
		{
			// Update the current node as the left half and return the right half. Also 
			// obtain the middle element, which is the key to be moved up to the parent.
			leftNode = path->top();
			rightNode = leftNode->Split(keyToParent);

			// check if currently split node is not the root node
			path->pop();
			if(!path->empty())
			{
				// Insert the middle key and the right half in to 
				// the parent. The parent will be an internal node.
				path->top()->Insert(*keyToParent, rightNode);
			}

			// if currently split node is the root node
			else
			{
				// set flag indicating that the root has popped from the stack
				rootPopped = true;
				break;
			}
		}

		// new internal node needs to be created and assigned as the root
		if(rootPopped)
		{
			// create a new internal node
			InternalNode* tempRoot = new InternalNode;

			//the case where we need one key for the root and its two children
			tempRoot->Insert(*keyToParent, leftNode, rightNode);

			// mark this new internal node as the root of the tree
			root = tempRoot;
		}

		delete(keyToParent);
		delete(path);
	}
}


// operation: Search(key)
void BPlusTree :: Search(int key)
{
	// check if tree is empty
	if(NULL == root)
	{
		outputFile<<"Null"<<endl;
	}

	// not empty, we then create stack with path containing all the node, 
	else
	{
		int i = 0;	
		
		// obtain the search path from root to leaf node and push it on to a stack
		stack<Node*>* path = new stack<Node*>;
		Search_Path(root, key, path);
		
		// search for the key in the leaf node, which is at the top of the stack
		vector<int> keys = path->top()->Get_Keys();
		vector< vector <string> > values = path->top()->Get_Values(); 
		vector<int>::iterator index = lower_bound(keys.begin(), keys.end(), key);

		// check if key is found
		if(key == keys[index - keys.begin()])
		{
			// display the values
			for(i = 0; i < values[index - keys.begin()].size() - 1; i++)
			{
				outputFile<<values[index - keys.begin()][i]<<",";
			}
			outputFile<<values[index - keys.begin()][i]<<endl;
		}

		// if key is not found
		else
		{
			outputFile<<"Null"<<endl;
		}

		delete(path);
	}
}


// operation: Search(key1, key2)
void BPlusTree :: Search(int key1, int key2)
{
	// check if tree is empty
	if(NULL == root)
	{
		outputFile<<"Null"<<endl;
	}

	// if it is a valid range search
	else
	{
		int i = 0;
		bool firstPass = true;
		int firstKey = -1;
		
		// obtain the search path from root to leaf node and push it on to a stack
		stack<Node*>* path = new stack<Node*>;
		Search_Path(root, key1, path);
		
		// search for the key in the leaf node, which is at the top of the stack
		vector<int> keys = path->top()->Get_Keys();
		vector< vector <string> > values = path->top()->Get_Values(); 
		Node* next = path->top()->Get_Next();
		vector<int>::iterator index = lower_bound(keys.begin(), keys.end(), key1);

		// display all the keys in the search range, along with their corresponding values
		while(1)
		{
			// check if end of the current leaf node is reached
			if((index - keys.begin()) == keys.size())
			{
 				// go to the next leaf node
				keys = next->Get_Keys();
                		values = next->Get_Values();
                		next = next->Get_Next();
				index = keys.begin();
			}	
			
			// save the smallest key in the given search range
			if(firstPass)
			{	
				firstKey = keys[index - keys.begin()];						
			}


			// check if already iterated through the doubly linked list once
			if(!(firstPass || (keys[index - keys.begin()] != firstKey)))
			{
				// exit the loop
				break;
			}

			// check if key is within the search range
			if((key1 <= keys[index - keys.begin()]) && (keys[index - keys.begin()] <= key2)) 
			{
				if(!firstPass)
				{
					outputFile<<",";
				}

				// display the key and its corresponding values
				for(i = 0; i < values[index - keys.begin()].size() - 1; i++)
				{
					outputFile<<values[index - keys.begin()][i]<<",";
				}
				outputFile<<values[index - keys.begin()][i];
			}

			// if key is not within the search range
			else
			{
				// check if atleast one key was in the search range
				if(!firstPass)
				{
					outputFile<<endl;
				}

				// if no keys belonged within the search range
				else
				{
					outputFile<<"Null"<<endl;
				}

				// exit the loop
				break;
			}

			firstPass = false;
			index++;
		}

		delete(path);
	}
}


// function to open the output file
void BPlusTree :: Open_Output_File()
{
	// open output file for writing
	outputFile.open(OUTPUT_FILE, ios::out | ios::trunc);
}


// function to close the output file
void BPlusTree :: Close_Output_File()
{
	// close the output file
	outputFile.close();
}


// destructor for tree
BPlusTree :: ~BPlusTree ()
{
	Destroy(root);
}

void BPlusTree :: Delete(int key)
{
     //similar to search but different on that we delete the keys and the corresponding values rather than display them out into
	 //the output file
	 if(root==NULL){
		  outputFile<<"there is nothing being inserted, please double check"<<endl;
     }
	 //otherwise, we do a search the path and check whether we are able to find the keys
	 else{
     int i=0;
		 stack<Node*>* path = new stack<Node*>;
	
		 Search_Path(root, key, path);

		 vector<int> keys=path->top()->Get_Keys();
		 vector< vector <string> > values=path->top()->Get_Values();
		 vector<int>::iterator index=lower_bound(keys.begin(), keys.end(), key);
		 //we check that whether the number of keys is greater than m/2
		 
		 //if after the deletion, it is still greater than order divided by two, then we just immediately delete it
		 if(key==keys[index-keys.begin()]){ 
			 //if after deleting one key it satisfies the rules
		  if((keys.size()-1)>=ceil(order/2)){
			//we immediately delete the key
			//how many values are there in our selected key?
		   i=values[index-keys.begin()].size();
			 values[index-keys.begin()].erase(values[index-keys.begin()].begin(), values[index-keys.begin()].begin()+i);
			 //values.erase(values.begin()+(index-keys.begin()));
			 //delete the corresponding key
			 
         
				 if(key==keys[0]){
					
			    //Node* tempnode = path->top();
				  path->pop();
				  vector<int> parentkeys=path->top()->Get_Keys();
				  vector<int>::iterator parentindex=lower_bound(parentkeys.begin(), parentkeys.end(), key);
					//do we find the correct key? yes we do:
					//is this key on the right, we will check for sure
					if(path->top()->Get_Children()[(parentindex-parentkeys.begin())+1]->Get_Keys().front()==key){
					    //what we will do is change the parent key to the next key in its child key
							keys.erase(keys.begin()+(index-keys.begin()));
							parentkeys[parentindex-parentkeys.begin()] = keys.front();
							} 
			    }
					else{
						keys.erase(keys.begin()+(index-keys.begin()));
					}
			//we immediately delete the key
			//how many values are there in our selected key?
		  
                     
        //if key is the begining, we need to move next key to the parent node
			 }
		   else if((keys.size()-1)<ceil(order/2)){
       //after the rotation the parent keys suppoed to be changed；
			 
			//  path->pop();
			//  vector<int> parentkey2=path->top()->Get_Keys();
			//  vector<int>::iterator parentindex2=lower_bound(parentkey2.begin(), parentkey2.end(), keys.begin());
			 //Still need to delete the key first
			 i=values[index-keys.begin()].size();
			 values[index-keys.begin()].erase(values[index-keys.begin()].begin(), values[index-keys.begin()].begin()+i);
			 //values.erase(values.begin()+(index-keys.begin()));
			 keys.erase(keys.begin()+(index-keys.begin()));
			 //under this condition, we probably first check if we can borrow from the sibling 
			 //check if this is leaf
			  
			 //get all the keys for the previous node
		   //we decide using store the current node in a temporary node, pop it first and then push it back
       Node* preleaf=NULL;
			 Node* tempnode=path->top();
			 path->pop();
			 Node* parent=path->top();
			 vector<int> pkey = parent->Get_Keys();
			 vector<Node*> parentc = parent->Get_Children();
			 vector<int>::iterator pkeyindex=lower_bound(pkey.begin(), pkey.end(), keys.front());
			 if(keys.front()==pkey[pkeyindex-pkey.begin()]){
				 //leftnode is the previous node
				  preleaf=parentc[pkeyindex-pkey.begin()];
			 }
			 path->push(tempnode);
			 //get the next key
			 Node* nextleaf = path->top()->Get_Next();
			
			 //Ensure that the prevkey has valid number of keys
			 if(preleaf!=NULL){
				  vector<int> prevkey= preleaf->Get_Keys();
			    vector<int>::iterator prevkeyindex=lower_bound(prevkey.begin(), prevkey.end(), prevkey.back());
					if((prevkey.size()-1)>=ceil(order/2)){
					if(prevkey.back()==prevkey[prevkeyindex-prevkey.begin()])
							{
                path->pop();
							  vector<int> parentkey2=path->top()->Get_Keys();
			          vector<int>::iterator parentindex2=lower_bound(parentkey2.begin(), parentkey2.end(), keys.front());
								parentkey2[parentindex2-parentkey2.begin()]=prevkey.back();
								keys.insert(keys.begin(), prevkey.back());
							  prevkey.erase(prevkey.begin()+(prevkeyindex-prevkey.begin()));
							}
						 }
						 else if(nextleaf!=NULL){
						  vector<int> nextkey= nextleaf->Get_Keys();
					    vector<int>::iterator nextkeyindex=lower_bound(nextkey.begin(), nextkey.end(), nextkey.front());
							if((nextkey.size()-1)>=ceil(order/2)){
  								if(nextkey.front()==nextkey[nextkeyindex-nextkey.begin()]){
                  path->pop();
									keys.insert(keys.end(), nextkey.front());
								  vector<int> parentkey3=path->top()->Get_Keys();
			            vector<int>::iterator parentindex3=lower_bound(parentkey3.begin(), parentkey3.end(), nextkey.front());
                  nextkey.erase(nextkey.begin()+(nextkeyindex-nextkey.begin()));
									parentkey3[parentindex3-parentkey3.begin()]=nextkey.front(); 
						  }
						 }
						}
			 }
				else if(nextleaf!=NULL){
							vector<int> nextkey1= nextleaf->Get_Keys();
					    vector<int>::iterator nextkeyindex1=lower_bound(nextkey1.begin(), nextkey1.end(), nextkey1.front());
							if((nextkey1.size()-1)>=ceil(order/2)){
  								if(nextkey1.front()==nextkey1[nextkeyindex1-nextkey1.begin()]){
                  path->pop();
									keys.insert(keys.end(), nextkey1.front());
								  vector<int> parentkey4=path->top()->Get_Keys();
			            vector<int>::iterator parentindex4=lower_bound(parentkey4.begin(), parentkey4.end(), nextkey1.front());
                  nextkey1.erase(nextkey1.begin()+(nextkeyindex1-nextkey1.begin()));
									parentkey4[parentindex4-parentkey4.begin()]=nextkey1.front(); 
						   }
						//if not possible, then we need to find the key on the right
							}	
				
	      
		 //else, we need to do something
		    }
	    }
		 }
		   delete(path);	
	 } 
	   
}

