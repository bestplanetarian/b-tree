#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <stack>
#include <algorithm>



#define MIN_ORDER 3
#define OUTPUT_FILE "output_file.txt"


using namespace std;


// generic node
class Node
{
	protected:
		bool isLeaf;
		vector<int> keys;
		Node* Left;
		Node* Right;

	public:
	    //is the node leaf?
		bool Get_IsLeaf();// checking if this is leaf
		vector<int> Get_Keys(); // 
		virtual void Insert(int key, string value){}
		virtual void Insert(int key, Node* rightChild){}//right insertion first
		virtual void Insert(int key, Node* leftChild, Node* rightChild){}// spliting only when necessary
		virtual void Search(int key){}
		virtual void Search(int key1, int key2){}
		virtual Node* Get_Left(){}
		virtual Node* Get_Right(){}
		virtual Node* Split(int* keyToParent){}
		virtual vector<Node*> Get_Children(){}
		virtual vector< vector <string> > Get_Values(){}
		virtual Node* Get_Next(){}
};


// internal node
class InternalNode : public Node
{
	private:
		vector<Node*> children;//children can be categorized as left child and right child

	public:
		InternalNode();
		void Insert(int key, Node* rightChild);
		void Insert(int key, Node* leftChild, Node* rightChild);
		Node* Split(int* keyToParent);
		vector<Node*> Get_Children();
		Node* Get_Left();
		Node* Get_Right();

};


// leaf node
class LeafNode : public Node
{
	private:
		LeafNode* prev;
		LeafNode* next;
		vector< vector <string> > values;

	public:
		LeafNode();
		void Insert(int key, string value);
		Node* Split(int* keyToParent);
		vector< vector <string> > Get_Values();
		Node* Get_Next();
};


// B+ tree
class BPlusTree
{
	private:
		int order;	
		Node* root;
		ofstream outputFile;
		void Search_Path(Node* node, int key, stack<Node*>* path);
		void Destroy(Node* node);
    public:
		void Initialize(int m);
		void Insert(int key, string value);
		void Search(int key);
		void Search(int key1, int key2);
		void Open_Output_File();
		void Close_Output_File();
		void Delete(int key);
		~BPlusTree();


};


